
# Corporate Restructuring Hub (Starter Site)

A clean, static website template for CorporateRestructuringHub.com

## Structure
- `index.html` — homepage (Latest, Tools, Playbooks, Case Library, Newsletter)
- `/posts/` — starter articles
- `/tools/`, `/playbooks/`, `/cases/` — section index pages
- `/assets/newsletter/` — Substack, ConvertKit, Mailchimp snippets (replace IDs/handles)
- `/images/hero.png` — hero (replace with a 1500×600 brand image)

## Deploy
- **Netlify**: drag-drop folder or connect repo; add custom domain, enable HTTPS.
- **GitHub Pages**: push to repo; Settings → Pages; optional custom domain via `CNAME`.

## Customize
- Colors in `style.css` (`--primary`, `--accent`, `--teal`).
- Replace newsletter snippets’ placeholders with real IDs.
- Update `sitemap.xml` with your live domain instead of `YOUR_DOMAIN`.

---
## Final Palette & Typography (Applied)
- Primary: #0A1F44
- Accent:  #C4A769
- Teal:    #16B3AC
- Muted:   #F5F7FA
- Text:    #0F172A
- Link:    #0A1F44
- Headings: Merriweather 700
- Body:     Inter 400/500/600/800

## Deploy Steps (Netlify)
1) Unzip `corporate-restructuring-hub_netlify_20251008-194336.zip` and drag the folder into Netlify (or connect a repo).
2) Add your custom domain `CorporateRestructuringHub.com` in Domain Management and follow DNS steps.
3) Enable HTTPS (Netlify will issue the certificate).

## Deploy Steps (GitHub Pages)
1) Unzip `corporate-restructuring-hub_github-pages_20251008-194336.zip`, push the folder to a new GitHub repo.
2) In **Settings → Pages**, select branch `main`, folder `/ (root)`.
3) Add the `CNAME` file content to your domain.
4) Point DNS to GitHub Pages per README (CNAME `www` → `<username>.github.io`, A records for apex).
